package com.bighitsplat;

import net.runelite.api.Actor;

public class ActiveHitsplat
{
    final Actor actor;
    final int damage;
    final int type;      // HitsplatID constant (e.g. DAMAGE_ME, BLOCK_ME, POISON, etc.)
    int ticksRemaining;

    public ActiveHitsplat(Actor actor, int damage, int type, int ticksRemaining)
    {
        this.actor = actor;
        this.damage = damage;
        this.type = type;
        this.ticksRemaining = ticksRemaining;
    }
}
