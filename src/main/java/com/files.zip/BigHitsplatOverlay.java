package com.bighitsplat;

import net.runelite.api.Actor;
import net.runelite.api.Client;
import net.runelite.api.HitsplatID;
import net.runelite.api.Point;
import net.runelite.client.ui.overlay.Overlay;
import net.runelite.client.ui.overlay.OverlayLayer;
import net.runelite.client.ui.overlay.OverlayPosition;

import javax.inject.Inject;
import java.awt.*;
import java.awt.geom.Ellipse2D;

public class BigHitsplatOverlay extends Overlay
{
    // Base hitsplat size in pixels (RuneLite's native hitsplats are ~30px)
    private static final int BASE_SIZE = 30;
    private static final Font HITSPLAT_FONT = new Font("Arial", Font.BOLD, 14);

    private final Client client;
    private final BigHitsplatPlugin plugin;
    private final BigHitsplatConfig config;

    private int lastTickCount = -1;

    @Inject
    public BigHitsplatOverlay(Client client, BigHitsplatPlugin plugin, BigHitsplatConfig config)
    {
        this.client = client;
        this.plugin = plugin;
        this.config = config;

        setPosition(OverlayPosition.DYNAMIC);
        setLayer(OverlayLayer.ABOVE_WIDGETS);
    }

    @Override
    public Dimension render(Graphics2D graphics)
    {
        // Tick hitsplat ages once per game tick
        int currentTick = client.getTickCount();
        if (currentTick != lastTickCount)
        {
            plugin.tickHitsplats();
            lastTickCount = currentTick;
        }

        for (ActiveHitsplat hitsplat : plugin.activeHitsplats)
        {
            Actor actor = hitsplat.actor;
            Point actorPoint = actor.getCanvasImageLocation(
                graphics,
                actor.getModel(),
                actor.getModelHeight()
            );

            if (actorPoint == null)
            {
                continue;
            }

            int scale = config.scale();
            int size = BASE_SIZE * scale;
            int x = actorPoint.getX() - size / 2;
            int y = actorPoint.getY() - size / 2;

            drawHitsplat(graphics, hitsplat, x, y, size);
        }

        return null;
    }

    private void drawHitsplat(Graphics2D g, ActiveHitsplat hitsplat, int x, int y, int size)
    {
        Color bgColor;
        Color borderColor;
        Color textColor = Color.WHITE;

        // Colour-code by hitsplat type to match OSRS style
        switch (hitsplat.type)
        {
            case HitsplatID.DAMAGE_ME:
                bgColor  = new Color(220, 30, 30, 220);   // red
                borderColor = new Color(140, 0, 0);
                break;
            case HitsplatID.BLOCK_ME:
                bgColor  = new Color(30, 100, 220, 220);  // blue (block/0)
                borderColor = new Color(0, 50, 150);
                break;
            case HitsplatID.POISON:
            case HitsplatID.VENOM:
                bgColor  = new Color(0, 160, 0, 220);     // green
                borderColor = new Color(0, 90, 0);
                break;
            case HitsplatID.HEAL:
                bgColor  = new Color(50, 205, 50, 220);   // lime
                borderColor = new Color(0, 120, 0);
                break;
            default:
                bgColor  = new Color(200, 200, 50, 220);  // yellow fallback
                borderColor = new Color(120, 120, 0);
                break;
        }

        // Draw filled circle
        Ellipse2D circle = new Ellipse2D.Float(x, y, size, size);
        g.setColor(bgColor);
        g.fill(circle);

        // Draw border
        g.setColor(borderColor);
        g.setStroke(new BasicStroke(2f));
        g.draw(circle);

        // Draw damage number
        if (config.showDamage())
        {
            String text = String.valueOf(hitsplat.damage);
            g.setFont(HITSPLAT_FONT.deriveFont((float)(12 * config.scale())));
            g.setColor(textColor);

            FontMetrics fm = g.getFontMetrics();
            int tx = x + (size - fm.stringWidth(text)) / 2;
            int ty = y + (size + fm.getAscent() - fm.getDescent()) / 2;

            // Drop shadow for readability
            g.setColor(Color.BLACK);
            g.drawString(text, tx + 1, ty + 1);
            g.setColor(textColor);
            g.drawString(text, tx, ty);
        }
    }
}
