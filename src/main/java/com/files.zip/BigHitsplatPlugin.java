package com.bighitsplat;

import com.google.inject.Provides;
import javax.inject.Inject;
import lombok.extern.slf4j.Slf4j;
import net.runelite.api.Client;
import net.runelite.api.Actor;
import net.runelite.api.events.HitsplatApplied;
import net.runelite.client.config.ConfigManager;
import net.runelite.client.eventbus.Subscribe;
import net.runelite.client.plugins.Plugin;
import net.runelite.client.plugins.PluginDescriptor;
import net.runelite.client.ui.overlay.OverlayManager;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@Slf4j
@PluginDescriptor(
    name = "Big Hitsplats",
    description = "Renders larger hitsplats on your character",
    tags = {"hitsplat", "damage", "overlay", "visual"}
)
public class BigHitsplatPlugin extends Plugin
{
    @Inject
    private Client client;

    @Inject
    private BigHitsplatConfig config;

    @Inject
    private BigHitsplatOverlay overlay;

    @Inject
    private OverlayManager overlayManager;

    // Each entry: {actor, damage, isMaxHit, ticksRemaining}
    final List<ActiveHitsplat> activeHitsplats = new ArrayList<>();

    @Override
    protected void startUp()
    {
        overlayManager.add(overlay);
        log.info("Big Hitsplats started");
    }

    @Override
    protected void shutDown()
    {
        overlayManager.remove(overlay);
        activeHitsplats.clear();
        log.info("Big Hitsplats stopped");
    }

    @Subscribe
    public void onHitsplatApplied(HitsplatApplied event)
    {
        Actor actor = event.getActor();

        // Only show hitsplats on the local player
        if (actor != client.getLocalPlayer())
        {
            return;
        }

        int damage = event.getHitsplat().getAmount();
        int type = event.getHitsplat().getHitsplatType();

        activeHitsplats.add(new ActiveHitsplat(actor, damage, type, config.displayTicks()));
    }

    /**
     * Called each game tick from the overlay to age/remove hitsplats.
     */
    void tickHitsplats()
    {
        Iterator<ActiveHitsplat> it = activeHitsplats.iterator();
        while (it.hasNext())
        {
            ActiveHitsplat h = it.next();
            h.ticksRemaining--;
            if (h.ticksRemaining <= 0)
            {
                it.remove();
            }
        }
    }

    @Provides
    BigHitsplatConfig provideConfig(ConfigManager configManager)
    {
        return configManager.getConfig(BigHitsplatConfig.class);
    }
}
