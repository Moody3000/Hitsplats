package com.bighitsplat;

import net.runelite.client.config.Config;
import net.runelite.client.config.ConfigGroup;
import net.runelite.client.config.ConfigItem;
import net.runelite.client.config.Range;

@ConfigGroup("bighitsplat")
public interface BigHitsplatConfig extends Config
{
    @Range(min = 1, max = 5)
    @ConfigItem(
        keyName = "scale",
        name = "Hitsplat Scale",
        description = "How many times larger to draw the hitsplat (1 = normal size)",
        position = 0
    )
    default int scale()
    {
        return 2;
    }

    @Range(min = 1, max = 10)
    @ConfigItem(
        keyName = "displayTicks",
        name = "Display Duration (ticks)",
        description = "How many game ticks to show each hitsplat",
        position = 1
    )
    default int displayTicks()
    {
        return 4;
    }

    @ConfigItem(
        keyName = "showOnNpcs",
        name = "Show on NPCs too",
        description = "Also render big hitsplats on NPCs you damage",
        position = 2
    )
    default boolean showOnNpcs()
    {
        return false;
    }

    @ConfigItem(
        keyName = "showDamage",
        name = "Show damage number",
        description = "Draw the damage number inside the hitsplat",
        position = 3
    )
    default boolean showDamage()
    {
        return true;
    }
}
